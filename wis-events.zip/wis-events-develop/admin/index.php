<?php 
// Silence is nearly golden..
